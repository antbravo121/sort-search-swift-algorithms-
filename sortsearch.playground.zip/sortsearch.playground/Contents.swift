import UIKit

func linear_search(list:Array<Int> , target:Int) -> Int {
    for (index, element) in list.enumerated() {
        if element == target{
            return index
        }
    }
    return -1
}

func binary_search(list:Array<Int>, target:Int) -> Int{
    var left = 0
    var right = list.count + 1
    
    while left <= right {
        let center = Int((left+right) / 2)
        
        if list[center] == target{
            return center
        } else if list[center] < target {
            left = center + 1
        } else if list[center] > target {
            right = center - 1
        }
    }
    return -1
}

func bubble_sort(list:Array<Int>) -> Array<Int> {
    var temp_list = list
    
    var i = 0
    while i < temp_list.count {
        var j = 0
        while j < temp_list.count - 1 {
            if temp_list[j + 1] < temp_list[j]{
                let temp = temp_list[j]
                temp_list[j] = temp_list[j+1]
                temp_list[j+1] = temp
            }
            j += 1
        }
        i += 1
    }
    return temp_list
}

func insertion_sort(list:Array<Int>) -> Array<Int> {
    var temp_list = list
    if temp_list.count < 1{
        return temp_list
    }
    
    var i = 0
    while i < temp_list.count {
        
        var j = i
        while j > 0 && temp_list[j] < temp_list[j - 1] {
            let temp = temp_list[j]
            temp_list[j] = temp_list[j - 1]
            temp_list[j - 1] = temp
            j -= 1
        }
        i += 1
    }
    return temp_list
}

